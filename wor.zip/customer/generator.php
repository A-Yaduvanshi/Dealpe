<?php 
    $number =  $_GET['number'];

    echo $number;
?>


<!DOCTYPE html>
<html>
<head>
<link href='https://fonts.googleapis.com/css?family=Libre Barcode 39' rel='stylesheet'>
<style>
body {
    font-family: 'Libre Barcode 39';font-size: 22px;
}
</style>
</head>
<body>

<h1>Libre Barcode 39</h1>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>
<p>123456790</p>
<p>ABCDEFGHIJKLMNOPQRSTUVWXYZ</p>
<p>abcdefghijklmnopqrstuvwxyz</p>

</body>
</html>
